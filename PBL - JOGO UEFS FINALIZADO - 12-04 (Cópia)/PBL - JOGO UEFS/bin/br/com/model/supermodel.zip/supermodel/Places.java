package br.com.model.supermodel;

import java.util.List;

import br.com.model.operational.Pair;

public class Places {
	private String nomeLocalString;
	private Pair posicaoLocalPair;
	private List<Events> listaEventosEvents;
}
