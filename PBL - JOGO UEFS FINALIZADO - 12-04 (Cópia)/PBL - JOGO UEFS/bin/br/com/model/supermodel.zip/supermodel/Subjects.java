package br.com.model.supermodel;

import java.util.ArrayList;
import java.util.List;

public class Subjects {
	private String nomeMateriaString;
	private int numeroProvasInt;
	private int cargaHorariaInt;
	private List<Double> notasProvasList;
	
	public Subjects(String nomeMateria, int numeroProvas, int cargaHoraria) {
		nomeMateriaString = nomeMateria;
		numeroProvasInt = numeroProvas;
		cargaHorariaInt = cargaHoraria;
		notasProvasList = new ArrayList<Double>(numeroProvas);
	}

	public String getNomeMateriaString() {
		return nomeMateriaString;
	}

	public int getNumeroProvasInt() {
		return numeroProvasInt;
	}

	public int getCargaHorariaInt() {
		return cargaHorariaInt;
	}

	public List<Double> getNotasProvasList() {
		return notasProvasList;
	}
	
}
