package br.com.model.supermodel;

import br.com.model.operational.Grid;
import br.com.model.operational.Grid.Pair;
import br.com.model.user.Features;

public class Characters {
	private String nomeString;
	private Grid posicaoGrid;
	private Features caracteristicasFeatures;
	private int idadeInt;
	
	public Characters(String nome, int idade) {
		nomeString = nome;
		idadeInt = idade;
		posicaoGrid = new Grid(0, 0);
		caracteristicasFeatures = new Features();
	}
	
	
	public void andarDireita() {
		posicaoGrid.axisX();
	}
	public void andarEsquerda() {
		posicaoGrid.negAxisX();
	}
	public void andarFrente() {
		posicaoGrid.axisY();
	}
	public void andarTras() {
		posicaoGrid.negAxisY();
	}

	public String getNomeString() {
		return nomeString;
	}

	public Grid getPosicaoGrid() {
		return posicaoGrid;
	}

	public int getIdadeInt() {
		return idadeInt;
	}


	public Features getCaracteristicasFeatures() {
		return caracteristicasFeatures;
	}


	public void setCaracteristicasFeatures(Features caracteristicasFeatures) {
		this.caracteristicasFeatures = caracteristicasFeatures;
	}
	
}
